
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Iterator;

	/**
	* Graph implementation that uses Adjacency Lists to store edges. It
	* contains one linked-list for every vertex i of the graph. The list for i
	* contains one instance of VertexAdjList for every vertex that is adjacent to i.
	* For directed graphs, if there is an edge from vertex i to vertex j then there is
	* a corresponding element in the adjacency list of node i (only). For
	* undirected graphs, if there is an edge between vertex i and vertex j, then there is a
	* corresponding element in the adjacency lists of *both* vertex i and vertex j. The
	* edges are not sorted; they contain the adjacent nodes in *order* of
	* edge insertion. In other words, for a graph, the node at the head of
	* the list of some vertex i corresponds to the edge involving i that was
	* added to the graph least recently (and has not been removed, yet). 
	*/

	public class GraphAdjList  implements Graph {

	// ATTRIBUTES: 
	    
	 //TO-DO

		int edgeCount;
		boolean directed;
		int vertices;
		LinkedList<Edge> adj_list[];
	 /* 
	  * CONSTRUCTOR: Creates a directed/undirected graph with V vertices and no edges.
	  * It initializes the array of adjacency edges so that each list is empty.
	  */
	    
	 
	public GraphAdjList(int V, boolean directed) {
		 adj_list = new LinkedList[V];
		 this.vertices = V;
		 this.directed = directed;

		 for(int i = 0; i < vertices; i++){
			 adj_list[i] = new LinkedList<Edge>();
		 }
		 
	 }

	 
	  // 1. IMPLEMENTATION METHOD numVerts: 
	  public int numVerts() { 

	    return vertices;     
     }

	  // 2. IMPLEMENTATION METHOD numEdges:
	  public int numEdges() { 
	    return edgeCount;
	    }
	    
	  //  3. IMPLEMENTATION METHOD addEdge:
	  public void addEdge(int v1, int v2, int w) {
		  Edge edge = new Edge(v2, w);
		  Edge edge1 = new Edge(v1, w); //Create edge object because you cant add (v2, w) to list because v2 is index which is out of bounds
	    	if(v1 >= vertices || v2 >= vertices) {
	    		System.out.println("Cannot add Edge. Out of bounds.");
	    	}
	    	else {
	    		if(hasEdge(v1, v2) == false) {
	    		if(directed == true) {
	    		adj_list[v1].add(edge);
	    		edgeCount++;
	    		}
	    		if(directed == false) {
	    			adj_list[v1].add(edge);
	    			if(v1 == v2) // check if the same edge is being added twice and if so, only add once i.e 2, 2 w 1 will appear twice without if statement
	    			{
	    				System.out.println("Cannot add the same edge twice.");
	    			}else {
	    			adj_list[v2].add(edge1);
	    			}
	    			edgeCount++;
	    		}
	    			
	    		}
	    		else {
	    			if(getWeightEdge(v1, v2) <= w) {
	    				if(directed == true) {
	    					removeEdge(v1, v2);
	    		    		adj_list[v1].add(edge);
	    		    		edgeCount++;
	    		    		}
	    		    		if(directed == false) {
	    		    			removeEdge(v1, v2);
	    		    			removeEdge(v2, v1);
	    		    			adj_list[v1].add(edge);
	    		    			adj_list[v2].add(edge1);
	    		    			
	    		    			
	    		    			edgeCount++;
	    		    		}
	    			}
	    			else {
	    				System.out.println("Edge Already Exists with a higher weight.");
	    			}
	    		}
	    		}
	    	
	    
    }
	  
	 // 4. IMPLEMENTATION METHOD removeEdge: 
	 public void removeEdge(int v1, int v2) {
		 if(v2 < vertices) {
		 if(directed == true) {
			 
		 for(Edge e : adj_list[v1]) {
			 if(e.getVertex() == v2) {
				 adj_list[v1].remove(e);
				 edgeCount--;
				 break;
			 }
		 }
		 }
		 if(directed == false) {
			 for(Edge e : adj_list[v1]) {
				 if(e.getVertex() == v2) {
					 adj_list[v1].remove(e);
					 edgeCount--;
					 break;
				 }
			 }
			 for(Edge j : adj_list[v2]) {
				 if(j.getVertex() == v1) {
					 adj_list[v2].remove(j);
					 break;
				 }
			 }
		 }
		 }
		 else {
			 System.out.println("Vertex "+v2+" doesnt exist.");
		 }
	}
	 
	 // 5. IMPLEMENTATION METHOD hasEdge:
	 public boolean hasEdge(int v1, int v2) {
		 boolean hasEdge = false;
		 if(directed == true) {
		 for(Edge e : adj_list[v1]) {
			 if(e.getVertex() == v2) {
				 hasEdge = true;
				 break;
			 }
			 else {
				 hasEdge = false;
			 }
			 
		 
		 }
		 }
		 if(directed == false) {
			 for(Edge e : adj_list[v1]) {
				 if(e.getVertex() == v2) {
					 hasEdge = true;
					 break;
				 }
			 }
		 }
		 return hasEdge;
	 
	 }

	// 6. IMPLEMENTATION METHOD getWeightEdge:
	 public int getWeightEdge(int v1, int v2) {
		 int res = 0;
		 for(Edge e : adj_list[v1]) {
			 if(e.getVertex() == v2) {
				 res = e.getWeight();
			 }
			
		 }
		 return res;
	 }

	// 7. IMPLEMENTATION METHOD getNeighbors:
	 public LinkedList<Integer> getNeighbors(int v) {
		 LinkedList<Integer> res = new LinkedList<Integer>();
		 if(directed == true) {
		 for(Edge e : adj_list[v]) {
			 res.add(e.getVertex());
		 }
		 }
		 if(directed == false) {
			 for(int i = 0; i < adj_list.length; i++) {
				 for(Edge e : adj_list[i]) {
					 if(e.getVertex() == v) {
						 res.add(i);
					 }
				 }
			 }
		 }
		 return res;
	 }

    // 8. IMPLEMENTATION METHOD getDegree:
	public int getDegree(int v) {
		int res = 0;
		if(directed == true) {
			res = 1;
			for(int i = 0; i < adj_list.length; i++) {
				for(Edge e : adj_list[i]) {
					if(e.getVertex() == v)
					res++;
				}
			}
		}
		if(directed == false) {
		for(int i = 0; i < adj_list.length; i++) {
			 for(Edge e : adj_list[i]) {
				 if(e.getVertex() == v) {
				 
					 res++;
				 }
				 
		}
		 }

		}
return res;	
	}

	// 9. IMPLEMENTATION METHOD toString:
	 public String toString() {
		 StringBuilder s = new StringBuilder();
		   for (int i = 0; i < vertices ; i++) {
	            if(adj_list[i].size() > 0) {
	                s.append("Vertex " + i + " is connected to: ");
	                for (int j = 0; j < adj_list[i].size(); j++) {
	                    s.append(adj_list[i].get(j) + " ");
	                }
	                s.append("\n");
	            }
	        }
		   return s.toString();
		   }

	}


