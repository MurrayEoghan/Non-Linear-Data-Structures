import java.util.LinkedList;

/*
 *  Implementation of the interface Graph with adjacency matrix.
*/

 
public class GraphAdjMatrix implements Graph{

	// ATTRIBUTES: 
    //TO-DO
	int vertices;
	int edges;
	boolean directed;
	int [][] graph;
    
    // CONSTRUCTOR: Creates a directed/undirected graph with V vertices and no edges
    public GraphAdjMatrix(int V, boolean directed) {
    	this.vertices = V;
    	this.directed = directed;
    	graph = new int[V][V];
    	
    }


    // 1. IMPLEMENTATION METHOD numVerts: 
    public int numVerts() { 
    return vertices;
    }
    
   
    // 2. IMPLEMENTATION METHOD numEdges:
    public int numEdges() { 
        return edges;
        }


   //  3. IMPLEMENTATION METHOD addEdge:
    public void addEdge(int v1, int v2, int w) {
    	
    	if(v1 >= vertices || v2 >= vertices) {
    		System.out.println("Cannot add Edge. Out of bounds.");
    	}
    	else {
		if(directed == true) {

    	 if(hasEdge(v1, v2) == false) {
    			
    			graph[v1][v2] = w;
            	edges++;
    		}
    		else {
    			if(getWeightEdge(v1, v2) < w) {
    				graph[v1][v2] = w;
    			}
    		}
    		

    	}
    		
    		if(directed == false) {
    			if(hasEdge(v1, v2) == false) {
    			if(getWeightEdge(v1, v2) < w) {
    				graph[v1][v2] = w;
    				graph[v2][v1] = w;
    				edges++;
    			}
    			else {
    				System.out.println("Edge already exists with a higher weight");
    			}
    			}
    			else {
    				if(hasEdge(v1, v2) == true)
    				graph[v1][v2] = w;
    				graph[v2][v1] = w;
    				
    			}
    		}        	}
    	
    }
    
    
   // 4. IMPLEMENTATION METHOD removeEdge:
   public void removeEdge (int v1, int v2)
   {
	   if(graph == null) {
		   System.out.println("Matrix is empty");
	   }
	   else if(v1 >= vertices) {
		   System.out.println("Vertex v1 "+v1+" doesnt exist.");
	   }
	   else if(v2 >= vertices) {
		   System.out.println("Vertex v2 "+v2+" doesnt exist.");
	   }
	   else {
		   if(directed == true) {
	   edges -= 1;
	   graph[v1][v2] = 0;
	   }
		   if(directed == false) {
			   edges -= 1;
			   graph[v1][v2] = 0;
			   graph[v2][v1] = 0;
		   }
	   }
	   
	 }

    // 5. IMPLEMENTATION METHOD hasEdge:
    public boolean hasEdge(int v1, int v2) {
    	boolean hasEdge = true;
    	if(directed == true) {
    	for(int i = 0; i < graph.length; i++) {
    		if(graph[v1][v2] != 0) {
    			hasEdge = true;
    		}
    		else {
    			hasEdge = false;
    		}
    	}
    	}
    	if(directed == false) {
    		for(int i = 0; i < graph.length; i++) {
    		if(graph[v1][v2]> 0) {
    			hasEdge = true;
    		}
    		else {
    			hasEdge = false;
    		}
    		}
    		
    	
    		
    	}
    	
    	return hasEdge;
    }
    
    // 6. IMPLEMENTATION METHOD getWeightEdge:
	public int getWeightEdge(int v1, int v2) {
		return	graph[v1][v2];
				}

    
	// 7. IMPLEMENTATION METHOD getNeighbors:
	@SuppressWarnings("rawtypes")
	public LinkedList getNeighbors(int v)
	{
		LinkedList<Integer> res = new LinkedList<Integer>();
		int count = vertices;
		int i = 0;
		if(directed == true) {
		while(i < count) {
			int val = getWeightEdge(v, i);
			if(val > 0) {
				res.add(i);
			}
			i++;
		}
		}
		if(directed == false) {
			while(i < count) {
				int val = getWeightEdge(v, i);
			//	int val2 = getWeightEdge(i, v);
				if(val > 0) {
					res.add(i);
				}
			
				i++;
			}
		}
		return res;
		
	}
   	
	// 8. IMPLEMENTATION METHOD getDegree:
	public int getDegree(int v) 
	{
		int count = vertices;
		int i = 0;
		int res = 0;
	   while(i < count) {
		   int val = getWeightEdge(v, i);
		   if(val > 0) {
			   res++;
		   }

		   i++;
	   }
	   return res;
	}
	

	// 9. IMPLEMENTATION METHOD toString:
   	public String toString()
    {
        StringBuilder s = new StringBuilder();
        s.append("No. of vertices : "+vertices + " No. of edges : " + edges + "\n");
        for (int v = 0; v < vertices; v++) {
            s.append(v + ": ");
           for(int e = 0; e < vertices; e++) {
        	  if(graph[v][e] > 0) {
               s.append(" "+getWeightEdge(v,e) + " ");
        	   }
        	   else {
        		   s.append(" 0 ");
        	   }
           }
        	   
           s.append("\n");
            
        
    }   
        return s.toString();

}
}